# Audibook

Audiobook is a mobile Audio Book app that was built completely using Flutter.
I built this app to practice and sharpen my skills in Flutter and explore its capabilities.

the main objective of this project is to build an audio player and handle all its features

## Features

- Audio Player
  - play the next and previous chapters
  - speed 2x
  - mute sound
  - play the next chapter immediately
  - jump to the end of the audio using the slider 
- Multiple widget styles to showcase the books on the main page.
- book details containing summary, rating, and tags.

